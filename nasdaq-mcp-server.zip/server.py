#!/usr/bin/env python3
"""
MCP Server for Top 5 NASDAQ Stocks Analysis
Provides real-time data, technical analysis, and options data
"""

import asyncio
import json
from typing import Any, Sequence
import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from mcp.server.models import InitializationOptions
from mcp.server import NotificationOptions, Server
from mcp.server.stdio import stdio_server
from mcp.types import (
    Resource,
    Tool,
    TextContent,
    ImageContent,
    EmbeddedResource,
    LoggingLevel
)

# Top 5 NASDAQ stocks by market cap
TOP_NASDAQ_STOCKS = ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN']

# Initialize MCP server
server = Server("nasdaq-analyzer")

def calculate_technical_indicators(hist_data: pd.DataFrame) -> dict:
    """Calculate comprehensive technical indicators"""
    try:
        # RSI
        delta = hist_data['Close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=14).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=14).mean()
        rs = gain / loss
        rsi = 100 - (100 / (1 + rs))
        
        # MACD
        exp1 = hist_data['Close'].ewm(span=12, adjust=False).mean()
        exp2 = hist_data['Close'].ewm(span=26, adjust=False).mean()
        macd = exp1 - exp2
        signal = macd.ewm(span=9, adjust=False).mean()
        
        # Bollinger Bands
        sma = hist_data['Close'].rolling(window=20).mean()
        std = hist_data['Close'].rolling(window=20).std()
        upper_band = sma + (std * 2)
        lower_band = sma - (std * 2)
        
        # Moving Averages
        sma_50 = hist_data['Close'].rolling(window=50).mean()
        sma_200 = hist_data['Close'].rolling(window=200).mean()
        
        # Volatility
        daily_returns = hist_data['Close'].pct_change()
        volatility = daily_returns.std() * np.sqrt(252) * 100
        
        # Volume analysis
        avg_volume = hist_data['Volume'].mean()
        
        return {
            'rsi': round(rsi.iloc[-1], 2) if not pd.isna(rsi.iloc[-1]) else None,
            'macd': round(macd.iloc[-1], 4) if not pd.isna(macd.iloc[-1]) else None,
            'macd_signal': round(signal.iloc[-1], 4) if not pd.isna(signal.iloc[-1]) else None,
            'bb_upper': round(upper_band.iloc[-1], 2) if not pd.isna(upper_band.iloc[-1]) else None,
            'bb_middle': round(sma.iloc[-1], 2) if not pd.isna(sma.iloc[-1]) else None,
            'bb_lower': round(lower_band.iloc[-1], 2) if not pd.isna(lower_band.iloc[-1]) else None,
            'sma_50': round(sma_50.iloc[-1], 2) if not pd.isna(sma_50.iloc[-1]) else None,
            'sma_200': round(sma_200.iloc[-1], 2) if not pd.isna(sma_200.iloc[-1]) else None,
            'volatility_annual': round(volatility, 2),
            'avg_volume': int(avg_volume)
        }
    except Exception as e:
        return {'error': str(e)}

def generate_trading_signals(ticker: str, current_price: float, indicators: dict, hist_data: pd.DataFrame) -> dict:
    """Generate buy/sell signals based on technical analysis"""
    signals = []
    score = 0
    
    # Price momentum
    price_1d = ((hist_data['Close'].iloc[-1] - hist_data['Close'].iloc[-2]) / hist_data['Close'].iloc[-2]) * 100
    price_5d = ((hist_data['Close'].iloc[-1] - hist_data['Close'].iloc[-6]) / hist_data['Close'].iloc[-6]) * 100
    price_20d = ((hist_data['Close'].iloc[-1] - hist_data['Close'].iloc[-21]) / hist_data['Close'].iloc[-21]) * 100
    
    # RSI analysis
    if indicators.get('rsi'):
        rsi = indicators['rsi']
        if rsi < 30:
            signals.append(f"RSI at {rsi} - Oversold, potential BUY")
            score += 2
        elif rsi > 70:
            signals.append(f"RSI at {rsi} - Overbought, potential SELL")
            score -= 2
        else:
            signals.append(f"RSI at {rsi} - Neutral")
    
    # MACD analysis
    if indicators.get('macd') and indicators.get('macd_signal'):
        if indicators['macd'] > indicators['macd_signal']:
            signals.append("MACD above signal - Bullish momentum")
            score += 1
        else:
            signals.append("MACD below signal - Bearish momentum")
            score -= 1
    
    # Bollinger Bands
    if indicators.get('bb_lower') and indicators.get('bb_upper'):
        if current_price <= indicators['bb_lower']:
            signals.append("Price at lower Bollinger Band - BUY zone")
            score += 2
        elif current_price >= indicators['bb_upper']:
            signals.append("Price at upper Bollinger Band - SELL zone")
            score -= 2
    
    # Moving Average Crossovers
    if indicators.get('sma_50') and indicators.get('sma_200'):
        if indicators['sma_50'] > indicators['sma_200']:
            signals.append("Golden Cross - 50 SMA above 200 SMA (Bullish)")
            score += 1
        elif indicators['sma_50'] < indicators['sma_200']:
            signals.append("Death Cross - 50 SMA below 200 SMA (Bearish)")
            score -= 1
    
    # Volume analysis
    current_volume = hist_data['Volume'].iloc[-1]
    if current_volume > indicators['avg_volume'] * 1.5:
        signals.append("High volume - Strong interest")
        score += 1
    
    # Momentum
    if price_5d > 5:
        signals.append(f"Strong upward momentum: +{price_5d:.2f}% (5d)")
        score += 1
    elif price_5d < -5:
        signals.append(f"Strong downward momentum: {price_5d:.2f}% (5d)")
        score -= 1
    
    # Final recommendation
    if score >= 3:
        recommendation = "STRONG BUY"
    elif score >= 1:
        recommendation = "BUY"
    elif score <= -3:
        recommendation = "STRONG SELL"
    elif score <= -1:
        recommendation = "SELL"
    else:
        recommendation = "HOLD"
    
    return {
        'recommendation': recommendation,
        'score': score,
        'signals': signals,
        'price_changes': {
            '1d': round(price_1d, 2),
            '5d': round(price_5d, 2),
            '20d': round(price_20d, 2)
        }
    }

async def get_stock_data(ticker: str) -> dict:
    """Fetch comprehensive stock data"""
    try:
        stock = yf.Ticker(ticker)
        
        # Get historical data
        hist = stock.history(period='1y')
        
        if len(hist) < 30:
            return {'error': 'Insufficient data'}
        
        # Current price and basic info
        current_price = hist['Close'].iloc[-1]
        info = stock.info
        
        # Technical indicators
        indicators = calculate_technical_indicators(hist)
        
        # Trading signals
        signals = generate_trading_signals(ticker, current_price, indicators, hist)
        
        # Company info
        company_data = {
            'ticker': ticker,
            'name': info.get('longName', ticker),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'current_price': round(current_price, 2),
            'market_cap': info.get('marketCap', 'N/A'),
            'pe_ratio': info.get('trailingPE', 'N/A'),
            'dividend_yield': info.get('dividendYield', 'N/A'),
            '52w_high': info.get('fiftyTwoWeekHigh', 'N/A'),
            '52w_low': info.get('fiftyTwoWeekLow', 'N/A'),
            'technical_indicators': indicators,
            'trading_signals': signals,
            'last_updated': datetime.now().isoformat()
        }
        
        return company_data
        
    except Exception as e:
        return {'error': str(e), 'ticker': ticker}

async def get_options_data(ticker: str) -> dict:
    """Fetch options data for a stock"""
    try:
        stock = yf.Ticker(ticker)
        expirations = stock.options
        
        if not expirations:
            return {'error': 'No options available', 'ticker': ticker}
        
        # Get nearest expiration
        nearest_exp = expirations[0]
        opt_chain = stock.option_chain(nearest_exp)
        
        # Get top calls and puts
        calls = opt_chain.calls.nlargest(10, 'volume')[['strike', 'lastPrice', 'bid', 'ask', 'volume', 'openInterest', 'impliedVolatility']]
        puts = opt_chain.puts.nlargest(10, 'volume')[['strike', 'lastPrice', 'bid', 'ask', 'volume', 'openInterest', 'impliedVolatility']]
        
        # Calculate Put/Call ratio
        total_call_volume = opt_chain.calls['volume'].sum()
        total_put_volume = opt_chain.puts['volume'].sum()
        pcr = total_put_volume / total_call_volume if total_call_volume > 0 else 0
        
        return {
            'ticker': ticker,
            'expiration': nearest_exp,
            'put_call_ratio': round(pcr, 2),
            'total_call_volume': int(total_call_volume),
            'total_put_volume': int(total_put_volume),
            'avg_call_iv': round(calls['impliedVolatility'].mean() * 100, 2),
            'avg_put_iv': round(puts['impliedVolatility'].mean() * 100, 2),
            'top_calls': calls.to_dict('records'),
            'top_puts': puts.to_dict('records')
        }
        
    except Exception as e:
        return {'error': str(e), 'ticker': ticker}

async def compare_stocks(tickers: list) -> dict:
    """Compare multiple stocks side by side"""
    comparison = []
    
    for ticker in tickers:
        data = await get_stock_data(ticker)
        if 'error' not in data:
            comparison.append({
                'ticker': ticker,
                'name': data['name'],
                'price': data['current_price'],
                'pe_ratio': data['pe_ratio'],
                'recommendation': data['trading_signals']['recommendation'],
                'score': data['trading_signals']['score'],
                'rsi': data['technical_indicators'].get('rsi'),
                'volatility': data['technical_indicators'].get('volatility_annual'),
                '5d_change': data['trading_signals']['price_changes']['5d'],
                '20d_change': data['trading_signals']['price_changes']['20d']
            })
    
    return {'comparison': comparison, 'timestamp': datetime.now().isoformat()}

@server.list_resources()
async def handle_list_resources() -> list[Resource]:
    """List available stock data resources"""
    resources = []
    
    for ticker in TOP_NASDAQ_STOCKS:
        resources.append(
            Resource(
                uri=f"nasdaq://{ticker}/overview",
                name=f"{ticker} Stock Overview",
                description=f"Complete analysis of {ticker} including price, technicals, and signals",
                mimeType="application/json",
            )
        )
        resources.append(
            Resource(
                uri=f"nasdaq://{ticker}/options",
                name=f"{ticker} Options Data",
                description=f"Options chain analysis for {ticker}",
                mimeType="application/json",
            )
        )
    
    resources.append(
        Resource(
            uri="nasdaq://comparison/top5",
            name="Top 5 NASDAQ Comparison",
            description="Side-by-side comparison of top 5 NASDAQ stocks",
            mimeType="application/json",
        )
    )
    
    return resources

@server.read_resource()
async def handle_read_resource(uri: str) -> str:
    """Read stock data resources"""
    if uri.startswith("nasdaq://"):
        parts = uri.replace("nasdaq://", "").split("/")
        
        if len(parts) == 2:
            ticker, resource_type = parts
            
            if resource_type == "overview":
                data = await get_stock_data(ticker.upper())
                return json.dumps(data, indent=2)
            
            elif resource_type == "options":
                data = await get_options_data(ticker.upper())
                return json.dumps(data, indent=2)
        
        elif parts[0] == "comparison" and parts[1] == "top5":
            data = await compare_stocks(TOP_NASDAQ_STOCKS)
            return json.dumps(data, indent=2)
    
    raise ValueError(f"Unknown resource: {uri}")

@server.list_tools()
async def handle_list_tools() -> list[Tool]:
    """List available analysis tools"""
    return [
        Tool(
            name="analyze_stock",
            description="Get comprehensive analysis of any stock including technical indicators, trading signals, and fundamentals",
            inputSchema={
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Stock ticker symbol (e.g., AAPL, MSFT)",
                    },
                },
                "required": ["ticker"],
            },
        ),
        Tool(
            name="get_options_analysis",
            description="Get detailed options chain analysis including Put/Call ratio, top contracts by volume, and implied volatility",
            inputSchema={
                "type": "object",
                "properties": {
                    "ticker": {
                        "type": "string",
                        "description": "Stock ticker symbol",
                    },
                },
                "required": ["ticker"],
            },
        ),
        Tool(
            name="compare_stocks",
            description="Compare multiple stocks side-by-side with key metrics and recommendations",
            inputSchema={
                "type": "object",
                "properties": {
                    "tickers": {
                        "type": "array",
                        "items": {"type": "string"},
                        "description": "List of stock tickers to compare (e.g., ['AAPL', 'MSFT', 'GOOGL'])",
                    },
                },
                "required": ["tickers"],
            },
        ),
        Tool(
            name="get_top_nasdaq",
            description="Get analysis of the top 5 NASDAQ stocks by market cap",
            inputSchema={
                "type": "object",
                "properties": {},
            },
        ),
        Tool(
            name="screen_stocks",
            description="Screen stocks based on technical criteria (RSI, signals, momentum)",
            inputSchema={
                "type": "object",
                "properties": {
                    "criteria": {
                        "type": "string",
                        "enum": ["oversold", "overbought", "strong_buy", "strong_sell", "high_momentum"],
                        "description": "Screening criteria to apply",
                    },
                },
                "required": ["criteria"],
            },
        ),
    ]

@server.call_tool()
async def handle_call_tool(
    name: str, arguments: dict | None
) -> list[TextContent | ImageContent | EmbeddedResource]:
    """Handle tool execution"""
    
    if name == "analyze_stock":
        ticker = arguments.get("ticker", "").upper()
        data = await get_stock_data(ticker)
        return [TextContent(type="text", text=json.dumps(data, indent=2))]
    
    elif name == "get_options_analysis":
        ticker = arguments.get("ticker", "").upper()
        data = await get_options_data(ticker)
        return [TextContent(type="text", text=json.dumps(data, indent=2))]
    
    elif name == "compare_stocks":
        tickers = [t.upper() for t in arguments.get("tickers", [])]
        data = await compare_stocks(tickers)
        return [TextContent(type="text", text=json.dumps(data, indent=2))]
    
    elif name == "get_top_nasdaq":
        data = await compare_stocks(TOP_NASDAQ_STOCKS)
        return [TextContent(type="text", text=json.dumps(data, indent=2))]
    
    elif name == "screen_stocks":
        criteria = arguments.get("criteria")
        results = []
        
        for ticker in TOP_NASDAQ_STOCKS:
            stock_data = await get_stock_data(ticker)
            
            if 'error' in stock_data:
                continue
            
            indicators = stock_data['technical_indicators']
            signals = stock_data['trading_signals']
            
            # Apply screening criteria
            match = False
            if criteria == "oversold" and indicators.get('rsi', 100) < 30:
                match = True
            elif criteria == "overbought" and indicators.get('rsi', 0) > 70:
                match = True
            elif criteria == "strong_buy" and signals['recommendation'] == "STRONG BUY":
                match = True
            elif criteria == "strong_sell" and signals['recommendation'] == "STRONG SELL":
                match = True
            elif criteria == "high_momentum" and signals['price_changes']['5d'] > 5:
                match = True
            
            if match:
                results.append({
                    'ticker': ticker,
                    'name': stock_data['name'],
                    'price': stock_data['current_price'],
                    'recommendation': signals['recommendation'],
                    'rsi': indicators.get('rsi'),
                    '5d_change': signals['price_changes']['5d']
                })
        
        return [TextContent(type="text", text=json.dumps({
            'criteria': criteria,
            'matches': results,
            'timestamp': datetime.now().isoformat()
        }, indent=2))]
    
    raise ValueError(f"Unknown tool: {name}")

async def main():
    """Run the MCP server"""
    async with stdio_server() as (read_stream, write_stream):
        await server.run(
            read_stream,
            write_stream,
            InitializationOptions(
                server_name="nasdaq-analyzer",
                server_version="1.0.0",
                capabilities=server.get_capabilities(
                    notification_options=NotificationOptions(),
                    experimental_capabilities={},
                ),
            ),
        )

if __name__ == "__main__":
    asyncio.run(main())
