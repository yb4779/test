#!/usr/bin/env python3
"""
HTTP Wrapper for NASDAQ MCP Server
Allows the MCP server to be accessed via HTTP on Cloud Run
"""

from flask import Flask, request, jsonify
import subprocess
import json
import asyncio
from server import (
    get_stock_data,
    get_options_data,
    compare_stocks,
    TOP_NASDAQ_STOCKS
)

app = Flask(__name__)

@app.route('/')
def index():
    """API documentation"""
    return jsonify({
        'name': 'NASDAQ MCP Server HTTP Wrapper',
        'version': '1.0.0',
        'description': 'Real-time NASDAQ stock analysis with technical indicators and trading signals',
        'endpoints': {
            '/stocks': 'List top 5 NASDAQ stocks',
            '/analyze/<ticker>': 'Get comprehensive stock analysis',
            '/options/<ticker>': 'Get options chain analysis',
            '/compare': 'Compare multiple stocks (POST with {"tickers": [...]})',
            '/screen/<criteria>': 'Screen stocks by criteria (oversold, overbought, strong_buy, strong_sell, high_momentum)',
            '/health': 'Health check endpoint'
        },
        'top_nasdaq_stocks': TOP_NASDAQ_STOCKS
    })

@app.route('/health')
def health():
    """Health check endpoint"""
    return jsonify({'status': 'healthy', 'service': 'nasdaq-mcp-server'})

@app.route('/stocks')
async def list_stocks():
    """List top 5 NASDAQ stocks with basic info"""
    results = []
    for ticker in TOP_NASDAQ_STOCKS:
        data = await get_stock_data(ticker)
        if 'error' not in data:
            results.append({
                'ticker': ticker,
                'name': data['name'],
                'price': data['current_price'],
                'recommendation': data['trading_signals']['recommendation']
            })
    return jsonify({'stocks': results})

@app.route('/analyze/<ticker>')
async def analyze_stock(ticker):
    """Get comprehensive stock analysis"""
    ticker = ticker.upper()
    data = await get_stock_data(ticker)
    return jsonify(data)

@app.route('/options/<ticker>')
async def get_options(ticker):
    """Get options analysis"""
    ticker = ticker.upper()
    data = await get_options_data(ticker)
    return jsonify(data)

@app.route('/compare', methods=['POST'])
async def compare():
    """Compare multiple stocks"""
    try:
        tickers = request.json.get('tickers', [])
        if not tickers:
            return jsonify({'error': 'Please provide tickers array'}), 400
        
        tickers = [t.upper() for t in tickers]
        data = await compare_stocks(tickers)
        return jsonify(data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/screen/<criteria>')
async def screen_stocks(criteria):
    """Screen stocks by criteria"""
    valid_criteria = ['oversold', 'overbought', 'strong_buy', 'strong_sell', 'high_momentum']
    
    if criteria not in valid_criteria:
        return jsonify({'error': f'Invalid criteria. Use one of: {valid_criteria}'}), 400
    
    results = []
    
    for ticker in TOP_NASDAQ_STOCKS:
        stock_data = await get_stock_data(ticker)
        
        if 'error' in stock_data:
            continue
        
        indicators = stock_data['technical_indicators']
        signals = stock_data['trading_signals']
        
        # Apply screening criteria
        match = False
        if criteria == "oversold" and indicators.get('rsi', 100) < 30:
            match = True
        elif criteria == "overbought" and indicators.get('rsi', 0) > 70:
            match = True
        elif criteria == "strong_buy" and signals['recommendation'] == "STRONG BUY":
            match = True
        elif criteria == "strong_sell" and signals['recommendation'] == "STRONG SELL":
            match = True
        elif criteria == "high_momentum" and signals['price_changes']['5d'] > 5:
            match = True
        
        if match:
            results.append({
                'ticker': ticker,
                'name': stock_data['name'],
                'price': stock_data['current_price'],
                'recommendation': signals['recommendation'],
                'rsi': indicators.get('rsi'),
                '5d_change': signals['price_changes']['5d']
            })
    
    return jsonify({
        'criteria': criteria,
        'matches': results,
        'total_matches': len(results)
    })

if __name__ == '__main__':
    # For Cloud Run
    import os
    port = int(os.environ.get('PORT', 8080))
    app.run(host='0.0.0.0', port=port, debug=False)
