# NASDAQ MCP Server - Deployment Guide

## 🚀 Quick Deploy to Google Cloud Run

### Step 1: Open Google Cloud Shell

Go to: https://console.cloud.google.com
Click the Cloud Shell icon (>_) in the top right

### Step 2: Upload Files

In Cloud Shell, upload the `nasdaq-mcp-server.zip` file:
1. Click the three dots menu (⋮) in Cloud Shell
2. Select "Upload"
3. Choose `nasdaq-mcp-server.zip`

### Step 3: Extract and Deploy

```bash
# Extract the files
unzip nasdaq-mcp-server.zip
cd nasdaq-mcp-server

# Make deployment script executable
chmod +x deploy-nasdaq-mcp.sh

# Deploy to Cloud Run
./deploy-nasdaq-mcp.sh
```

### Step 4: Wait for Deployment

The deployment process will:
- ✅ Enable required Google Cloud APIs
- ✅ Build your Docker container
- ✅ Deploy to Cloud Run
- ✅ Configure auto-scaling and public access

**This takes approximately 3-5 minutes**

### Step 5: Get Your Service URL

After successful deployment, you'll see:
```
🎉 NASDAQ MCP Server is now live!
Service URL: https://nasdaq-mcp-server-xxxxx-uc.a.run.app
```

## 🧪 Test Your Deployment

### 1. Health Check
```bash
curl https://your-service-url.run.app/health
```

Expected response:
```json
{
  "status": "healthy",
  "service": "nasdaq-mcp-server"
}
```

### 2. List Top NASDAQ Stocks
```bash
curl https://your-service-url.run.app/stocks
```

### 3. Analyze a Stock
```bash
curl https://your-service-url.run.app/analyze/AAPL
```

### 4. Get Options Data
```bash
curl https://your-service-url.run.app/options/MSFT
```

### 5. Screen for Oversold Stocks
```bash
curl https://your-service-url.run.app/screen/oversold
```

## 📊 Available API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | API documentation |
| `/health` | GET | Health check |
| `/stocks` | GET | List top 5 NASDAQ stocks |
| `/analyze/<ticker>` | GET | Full stock analysis |
| `/options/<ticker>` | GET | Options chain data |
| `/compare` | POST | Compare multiple stocks |
| `/screen/<criteria>` | GET | Screen by criteria |

## 🔍 Screening Criteria

- `oversold` - RSI < 30
- `overbought` - RSI > 70
- `strong_buy` - Strong buy signals
- `strong_sell` - Strong sell signals
- `high_momentum` - >5% gain in 5 days

## 💡 Usage Examples

### Python
```python
import requests

# Analyze a stock
response = requests.get('https://your-service-url.run.app/analyze/AAPL')
data = response.json()
print(f"Recommendation: {data['trading_signals']['recommendation']}")
print(f"Price: ${data['current_price']}")
print(f"RSI: {data['technical_indicators']['rsi']}")

# Compare stocks
response = requests.post(
    'https://your-service-url.run.app/compare',
    json={'tickers': ['AAPL', 'MSFT', 'GOOGL']}
)
comparison = response.json()
for stock in comparison['comparison']:
    print(f"{stock['ticker']}: {stock['recommendation']}")
```

### JavaScript
```javascript
// Analyze a stock
fetch('https://your-service-url.run.app/analyze/NVDA')
  .then(response => response.json())
  .then(data => {
    console.log('Recommendation:', data.trading_signals.recommendation);
    console.log('Price:', data.current_price);
    console.log('RSI:', data.technical_indicators.rsi);
  });

// Screen for opportunities
fetch('https://your-service-url.run.app/screen/oversold')
  .then(response => response.json())
  .then(data => {
    console.log('Oversold stocks:', data.matches);
  });
```

### curl
```bash
# Get full analysis with formatted JSON
curl https://your-service-url.run.app/analyze/AAPL | jq .

# Compare stocks
curl -X POST https://your-service-url.run.app/compare \
  -H "Content-Type: application/json" \
  -d '{"tickers": ["AAPL", "MSFT", "GOOGL", "AMZN", "NVDA"]}'

# Find high momentum stocks
curl https://your-service-url.run.app/screen/high_momentum | jq .
```

## 🔧 Troubleshooting

### Issue: "Permission denied" error
**Solution:** Make sure you have the right permissions in your Google Cloud project

```bash
gcloud auth login
gcloud config set project project-c81256ce-f16a-4b33-a0b
```

### Issue: Build fails
**Solution:** Ensure all files are present:
```bash
ls -la
# Should see: server.py, http_wrapper.py, requirements.txt, Dockerfile
```

### Issue: Service won't start
**Solution:** Check Cloud Run logs:
```bash
gcloud run services logs read nasdaq-mcp-server --region us-central1
```

### Issue: Timeout errors
**Solution:** The service has a 1-hour timeout. For long-running requests, this should be sufficient. If you still get timeouts, check your network connection.

## 💰 Cost Estimates

Cloud Run pricing (as of 2024):
- **First 2 million requests/month**: FREE
- **CPU**: $0.00002400 per vCPU-second
- **Memory**: $0.00000250 per GiB-second
- **With auto-scaling to 0**: Only pay when requests are being processed

**Typical costs for moderate use:** $1-5/month

## 🔒 Security Considerations

The current deployment allows **unauthenticated access** for easy testing.

For production use, you may want to:

1. **Add authentication:**
```bash
gcloud run deploy nasdaq-mcp-server \
  --no-allow-unauthenticated \
  --region us-central1
```

2. **Use API keys or OAuth**

3. **Set up rate limiting**

## 📈 Monitoring

View your service metrics:
```bash
# Open Cloud Console
https://console.cloud.google.com/run/detail/us-central1/nasdaq-mcp-server/metrics

# Or use gcloud
gcloud run services describe nasdaq-mcp-server --region us-central1
```

## 🔄 Updating the Service

To deploy updates:
```bash
cd nasdaq-mcp-server
./deploy-nasdaq-mcp.sh
```

This will rebuild and redeploy with zero downtime.

## 🗑️ Deleting the Service

If you want to remove the deployment:
```bash
gcloud run services delete nasdaq-mcp-server --region us-central1
```

## 📞 Support

For issues:
1. Check the `/health` endpoint
2. Review Cloud Run logs
3. Test with curl commands above
4. Verify your Google Cloud project settings

## ⚠️ Important Reminders

- This is for **educational purposes only**
- **NOT financial advice** - always DYOR
- Stock data from Yahoo Finance (may have delays)
- Market hours: data is most accurate during trading hours
- Rate limits apply to Yahoo Finance data

## 🎉 Next Steps

After deployment:
1. Save your service URL
2. Test all endpoints
3. Integrate with your applications
4. Set up monitoring/alerts if needed
5. Consider adding authentication for production use

Your NASDAQ MCP Server is now ready to provide real-time stock analysis!
