# NASDAQ MCP Server

Model Context Protocol (MCP) server for analyzing top 5 NASDAQ stocks with comprehensive technical analysis, trading signals, and options data.

## 🎯 Overview

This MCP server provides real-time analysis of the top 5 NASDAQ stocks by market cap:
- **AAPL** - Apple Inc.
- **MSFT** - Microsoft Corporation
- **NVDA** - NVIDIA Corporation
- **GOOGL** - Alphabet Inc.
- **AMZN** - Amazon.com Inc.

## 📊 Features

### Stock Analysis
- **Real-time Price Data** - Current prices, market cap, P/E ratio, dividend yield
- **Technical Indicators**:
  - RSI (Relative Strength Index)
  - MACD (Moving Average Convergence Divergence)
  - Bollinger Bands
  - 50-day and 200-day Moving Averages
  - Annualized Volatility
- **Trading Signals** - AI-powered BUY/SELL/HOLD recommendations
- **Price Momentum** - 1-day, 5-day, and 20-day percentage changes

### Options Analysis
- Put/Call Ratio (volume & open interest)
- Top 10 calls and puts by volume
- Average Implied Volatility for calls and puts
- Complete options chain data

### Comparison Tools
- Side-by-side stock comparison
- Screening by criteria (oversold, overbought, momentum)
- Performance benchmarking

## 🚀 Deployment Options

### Option 1: Cloud Run with HTTP Wrapper (Recommended)

The server includes an HTTP wrapper that makes it accessible via REST API on Cloud Run.

```bash
# Deploy to Cloud Run
chmod +x deploy.sh
./deploy.sh
```

### Option 2: Local MCP Server (for Claude Desktop)

For local use with Claude Desktop or other MCP clients:

```bash
# Install dependencies
pip install -r requirements.txt

# Run MCP server
python server.py
```

Then configure in Claude Desktop's config file:

**macOS**: `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows**: `%APPDATA%\Claude\claude_desktop_config.json`

```json
{
  "mcpServers": {
    "nasdaq-analyzer": {
      "command": "python",
      "args": ["/path/to/server.py"]
    }
  }
}
```

## 🔌 HTTP API Endpoints

Once deployed to Cloud Run, you can access:

### `GET /`
API documentation and available endpoints

### `GET /health`
Health check endpoint

### `GET /stocks`
List top 5 NASDAQ stocks with basic info

### `GET /analyze/<ticker>`
Get comprehensive analysis for a specific stock
```bash
curl https://your-service.run.app/analyze/AAPL
```

Response includes:
- Company information
- Current price and fundamentals
- Technical indicators (RSI, MACD, Bollinger Bands, etc.)
- Trading signals and recommendations
- Price momentum analysis

### `GET /options/<ticker>`
Get options chain analysis
```bash
curl https://your-service.run.app/options/MSFT
```

### `POST /compare`
Compare multiple stocks
```bash
curl -X POST https://your-service.run.app/compare \
  -H "Content-Type: application/json" \
  -d '{"tickers": ["AAPL", "MSFT", "GOOGL"]}'
```

### `GET /screen/<criteria>`
Screen stocks by criteria

Available criteria:
- `oversold` - RSI < 30
- `overbought` - RSI > 70
- `strong_buy` - Strong buy signal
- `strong_sell` - Strong sell signal
- `high_momentum` - >5% gain in 5 days

```bash
curl https://your-service.run.app/screen/oversold
```

## 🛠️ MCP Resources

The server exposes these MCP resources:

- `nasdaq://AAPL/overview` - Complete analysis of AAPL
- `nasdaq://MSFT/overview` - Complete analysis of MSFT
- `nasdaq://NVDA/overview` - Complete analysis of NVDA
- `nasdaq://GOOGL/overview` - Complete analysis of GOOGL
- `nasdaq://AMZN/overview` - Complete analysis of AMZN
- `nasdaq://AAPL/options` - Options data for AAPL
- (similar for other stocks)
- `nasdaq://comparison/top5` - Comparison of all 5 stocks

## 🧰 MCP Tools

### `analyze_stock`
Analyze any stock ticker
```json
{
  "ticker": "AAPL"
}
```

### `get_options_analysis`
Get options data for a stock
```json
{
  "ticker": "MSFT"
}
```

### `compare_stocks`
Compare multiple stocks
```json
{
  "tickers": ["AAPL", "MSFT", "NVDA"]
}
```

### `get_top_nasdaq`
Get analysis of top 5 NASDAQ stocks
```json
{}
```

### `screen_stocks`
Screen stocks by criteria
```json
{
  "criteria": "oversold"
}
```

## 📈 Signal Generation

Trading signals are generated using a multi-factor scoring system:

**Bullish Indicators (+points)**:
- RSI < 30 (oversold): +2
- MACD above signal: +1
- Price at lower Bollinger Band: +2
- Golden Cross (50 SMA > 200 SMA): +1
- High volume (>1.5x average): +1
- Strong upward momentum (>5% in 5d): +1

**Bearish Indicators (-points)**:
- RSI > 70 (overbought): -2
- MACD below signal: -1
- Price at upper Bollinger Band: -2
- Death Cross (50 SMA < 200 SMA): -1
- Strong downward momentum (<-5% in 5d): -1

**Final Recommendations**:
- Score ≥ +3: **STRONG BUY**
- Score +1 to +2: **BUY**
- Score -1 to +1: **HOLD**
- Score -2 to -3: **SELL**
- Score ≤ -3: **STRONG SELL**

## 💡 Example Use Cases

### 1. Daily Market Overview
```bash
curl https://your-service.run.app/stocks
```

### 2. Deep Dive on Specific Stock
```bash
curl https://your-service.run.app/analyze/NVDA
```

### 3. Find Oversold Opportunities
```bash
curl https://your-service.run.app/screen/oversold
```

### 4. Compare Tech Giants
```bash
curl -X POST https://your-service.run.app/compare \
  -H "Content-Type: application/json" \
  -d '{"tickers": ["AAPL", "MSFT", "GOOGL", "AMZN"]}'
```

### 5. Options Analysis for Earnings
```bash
curl https://your-service.run.app/options/AAPL
```

## 📊 Data Sources

- **Stock Data**: Yahoo Finance (via yfinance)
- **Technical Indicators**: Calculated in real-time from historical data
- **Options Data**: Real-time options chains from Yahoo Finance

## ⚠️ Disclaimer

This tool provides **educational analysis only** and is **NOT financial advice**. 

- All analysis is based on historical data and technical indicators
- Past performance does not guarantee future results
- Always do your own research (DYOR)
- Consult with licensed financial advisors before making investment decisions
- Use at your own risk

## 🔧 Configuration

### Environment Variables
- `PORT` - HTTP server port (default: 8080)
- `PYTHONUNBUFFERED` - Set to 1 for Cloud Run logging

### Customization

To analyze different stocks, edit the `TOP_NASDAQ_STOCKS` list in `server.py`:

```python
TOP_NASDAQ_STOCKS = ['AAPL', 'MSFT', 'NVDA', 'GOOGL', 'AMZN']
```

## 📦 Project Structure

```
nasdaq-mcp-server/
├── server.py           # Core MCP server with tools and resources
├── http_wrapper.py     # Flask HTTP wrapper for Cloud Run
├── requirements.txt    # Python dependencies
├── Dockerfile         # Container configuration
├── deploy.sh          # Cloud Run deployment script
└── README.md          # This file
```

## 🚀 Cloud Run Deployment

The deployment script will:
1. Enable required Google Cloud APIs
2. Build a Docker container
3. Deploy to Cloud Run with:
   - 1GB memory
   - Auto-scaling (0-10 instances)
   - Public access (unauthenticated)
   - 1-hour timeout for long-running analysis

After deployment, you'll get a URL like:
```
https://nasdaq-mcp-server-xxxxx-uc.a.run.app
```

## 🔗 Integration Examples

### With curl
```bash
# Get stock analysis
curl https://your-service.run.app/analyze/AAPL | jq .

# Screen for buying opportunities
curl https://your-service.run.app/screen/oversold | jq .
```

### With Python
```python
import requests

# Analyze a stock
response = requests.get('https://your-service.run.app/analyze/MSFT')
data = response.json()
print(f"Recommendation: {data['trading_signals']['recommendation']}")

# Compare stocks
response = requests.post(
    'https://your-service.run.app/compare',
    json={'tickers': ['AAPL', 'MSFT', 'GOOGL']}
)
comparison = response.json()
```

### With Claude Desktop (MCP)
Add to your Claude Desktop config and ask:
- "Analyze AAPL stock"
- "Compare the top 5 NASDAQ stocks"
- "Find oversold stocks in the top 5 NASDAQ"
- "What are the options for NVDA?"

## 📞 Support

For issues or questions:
- Check the `/` endpoint for API documentation
- Use `/health` endpoint to verify service status
- Review logs in Google Cloud Console

## 📄 License

Educational use only. Not for production financial decision making.
