#!/bin/bash

# Configuration
PROJECT_ID="project-c81256ce-f16a-4b33-a0b"
REGION="us-central1"
SERVICE_NAME="nasdaq-mcp-server"

echo "🚀 Deploying NASDAQ MCP Server to Google Cloud Run"
echo "===================================================="
echo ""

# Set the project
echo "📋 Setting project to: $PROJECT_ID"
gcloud config set project $PROJECT_ID

echo ""
echo "🔧 Enabling required APIs..."
gcloud services enable cloudbuild.googleapis.com
gcloud services enable run.googleapis.com
gcloud services enable containerregistry.googleapis.com

echo ""
echo "🏗️  Building and deploying to Cloud Run..."
echo "This may take a few minutes..."
echo ""

gcloud run deploy $SERVICE_NAME \
  --source . \
  --platform managed \
  --region $REGION \
  --allow-unauthenticated \
  --memory 1Gi \
  --cpu 1 \
  --timeout 3600 \
  --max-instances 10 \
  --min-instances 0 \
  --set-env-vars "PYTHONUNBUFFERED=1"

if [ $? -eq 0 ]; then
    echo ""
    echo "✅ Deployment successful!"
    echo ""
    echo "📊 Getting your service URL..."
    SERVICE_URL=$(gcloud run services describe $SERVICE_NAME --region $REGION --format 'value(status.url)')
    
    echo ""
    echo "=================================================="
    echo "🎉 NASDAQ MCP Server is now live!"
    echo "=================================================="
    echo ""
    echo "Service URL: $SERVICE_URL"
    echo ""
    echo "📡 Available Endpoints:"
    echo "  • API Documentation:  $SERVICE_URL/"
    echo "  • Health Check:       $SERVICE_URL/health"
    echo "  • List Stocks:        $SERVICE_URL/stocks"
    echo "  • Analyze Stock:      $SERVICE_URL/analyze/AAPL"
    echo "  • Options Data:       $SERVICE_URL/options/MSFT"
    echo "  • Screen Stocks:      $SERVICE_URL/screen/oversold"
    echo ""
    echo "🧪 Test your deployment:"
    echo "  curl $SERVICE_URL/health"
    echo "  curl $SERVICE_URL/stocks"
    echo "  curl $SERVICE_URL/analyze/AAPL"
    echo ""
    echo "=================================================="
else
    echo ""
    echo "❌ Deployment failed. Please check the errors above."
    exit 1
fi
