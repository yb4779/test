#!/usr/bin/env python3
"""
Test script for NASDAQ MCP Server
Tests all major functionality before deployment
"""

import asyncio
import sys
import json
from server import (
    get_stock_data,
    get_options_data,
    compare_stocks,
    TOP_NASDAQ_STOCKS
)

async def test_stock_analysis():
    """Test stock data retrieval and analysis"""
    print("\n" + "="*60)
    print("TEST 1: Stock Analysis")
    print("="*60)
    
    ticker = "AAPL"
    print(f"\nAnalyzing {ticker}...")
    
    data = await get_stock_data(ticker)
    
    if 'error' in data:
        print(f"❌ ERROR: {data['error']}")
        return False
    
    print(f"✅ Successfully retrieved data for {data['name']}")
    print(f"   Price: ${data['current_price']}")
    print(f"   Recommendation: {data['trading_signals']['recommendation']}")
    print(f"   Signal Score: {data['trading_signals']['score']}")
    print(f"   RSI: {data['technical_indicators'].get('rsi')}")
    
    return True

async def test_options_analysis():
    """Test options data retrieval"""
    print("\n" + "="*60)
    print("TEST 2: Options Analysis")
    print("="*60)
    
    ticker = "MSFT"
    print(f"\nGetting options data for {ticker}...")
    
    data = await get_options_data(ticker)
    
    if 'error' in data:
        print(f"❌ ERROR: {data['error']}")
        return False
    
    print(f"✅ Successfully retrieved options data")
    print(f"   Expiration: {data['expiration']}")
    print(f"   Put/Call Ratio: {data['put_call_ratio']}")
    print(f"   Total Call Volume: {data['total_call_volume']:,}")
    print(f"   Total Put Volume: {data['total_put_volume']:,}")
    
    return True

async def test_comparison():
    """Test stock comparison"""
    print("\n" + "="*60)
    print("TEST 3: Stock Comparison")
    print("="*60)
    
    tickers = ["AAPL", "MSFT", "NVDA"]
    print(f"\nComparing {', '.join(tickers)}...")
    
    data = await compare_stocks(tickers)
    
    if not data.get('comparison'):
        print("❌ ERROR: No comparison data returned")
        return False
    
    print(f"✅ Successfully compared {len(data['comparison'])} stocks")
    
    for stock in data['comparison']:
        print(f"\n   {stock['ticker']} ({stock['name']})")
        print(f"   Price: ${stock['price']}")
        print(f"   Recommendation: {stock['recommendation']}")
        print(f"   5-day change: {stock['5d_change']}%")
    
    return True

async def test_top_nasdaq():
    """Test top NASDAQ stocks analysis"""
    print("\n" + "="*60)
    print("TEST 4: Top 5 NASDAQ Analysis")
    print("="*60)
    
    print(f"\nAnalyzing top 5 NASDAQ stocks: {', '.join(TOP_NASDAQ_STOCKS)}...")
    
    data = await compare_stocks(TOP_NASDAQ_STOCKS)
    
    if not data.get('comparison'):
        print("❌ ERROR: No comparison data returned")
        return False
    
    print(f"✅ Successfully analyzed {len(data['comparison'])} stocks")
    
    # Count recommendations
    recommendations = {}
    for stock in data['comparison']:
        rec = stock['recommendation']
        recommendations[rec] = recommendations.get(rec, 0) + 1
    
    print("\n   Recommendation Summary:")
    for rec, count in recommendations.items():
        print(f"   {rec}: {count}")
    
    return True

async def test_screening():
    """Test stock screening functionality"""
    print("\n" + "="*60)
    print("TEST 5: Stock Screening")
    print("="*60)
    
    criteria_list = ['oversold', 'overbought', 'strong_buy', 'high_momentum']
    
    for criteria in criteria_list:
        print(f"\nScreening for '{criteria}'...")
        
        matches = []
        for ticker in TOP_NASDAQ_STOCKS:
            stock_data = await get_stock_data(ticker)
            
            if 'error' in stock_data:
                continue
            
            indicators = stock_data['technical_indicators']
            signals = stock_data['trading_signals']
            
            # Apply screening criteria
            match = False
            if criteria == "oversold" and indicators.get('rsi', 100) < 30:
                match = True
            elif criteria == "overbought" and indicators.get('rsi', 0) > 70:
                match = True
            elif criteria == "strong_buy" and signals['recommendation'] == "STRONG BUY":
                match = True
            elif criteria == "high_momentum" and signals['price_changes']['5d'] > 5:
                match = True
            
            if match:
                matches.append(ticker)
        
        if matches:
            print(f"   ✅ Found matches: {', '.join(matches)}")
        else:
            print(f"   ℹ️  No matches found for '{criteria}'")
    
    return True

async def run_all_tests():
    """Run all tests"""
    print("\n" + "="*60)
    print("NASDAQ MCP SERVER - TEST SUITE")
    print("="*60)
    
    tests = [
        ("Stock Analysis", test_stock_analysis),
        ("Options Analysis", test_options_analysis),
        ("Stock Comparison", test_comparison),
        ("Top NASDAQ Analysis", test_top_nasdaq),
        ("Stock Screening", test_screening),
    ]
    
    results = []
    
    for test_name, test_func in tests:
        try:
            result = await test_func()
            results.append((test_name, result))
        except Exception as e:
            print(f"\n❌ Test '{test_name}' failed with exception: {e}")
            results.append((test_name, False))
    
    # Summary
    print("\n" + "="*60)
    print("TEST SUMMARY")
    print("="*60)
    
    passed = sum(1 for _, result in results if result)
    total = len(results)
    
    for test_name, result in results:
        status = "✅ PASSED" if result else "❌ FAILED"
        print(f"{status}: {test_name}")
    
    print(f"\nTotal: {passed}/{total} tests passed")
    
    if passed == total:
        print("\n🎉 All tests passed! Server is ready for deployment.")
        return 0
    else:
        print(f"\n⚠️  {total - passed} test(s) failed. Please check the errors above.")
        return 1

if __name__ == "__main__":
    exit_code = asyncio.run(run_all_tests())
    sys.exit(exit_code)
